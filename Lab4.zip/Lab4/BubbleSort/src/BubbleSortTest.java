import static org.junit.Assert.assertEquals;

import java.util.Arrays;

import org.junit.Test;

public class BubbleSortTest {
	@Test
	public void Test() {
		BubbleSort test = new BubbleSort();
		int w[] = {1,6,2,2,5};
        int p[] = {1,2,2,5,6};
		assertEquals(Arrays.toString(p), Arrays.toString(test.BubbleSort(w)));
	}

}
